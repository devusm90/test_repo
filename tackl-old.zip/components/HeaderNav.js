import React, { Component } from 'react';
import { ScrollView, StyleSheet, View,ImageBackground, Text, Pressable, FlatList,Image } from 'react-native';
import { useNavigation } from '@react-navigation/native';



export default function HeaderNav() {
  
  const navigation = useNavigation();
  const goHome =()=>{
    navigation.navigate('Home')
  }
  return (
  <View style={styles.hdrnavwrap}>
    <Pressable style={styles.btmbtn} onPress={goHome}>
      <Image style={styles.userimg} source={require('../assets/images/user.png')} />
    </Pressable>

    <View style={styles.alglft}>
      <Pressable style={styles.btmbtn} onPress={() => navigation.navigate('Notification')}>
      <Image style={styles.notimg} source={require('../assets/images/notification.png')} />
      </Pressable>
      <Pressable style={styles.btmbtn} onPress={() => navigation.navigate('Search')}>
      <Image style={styles.srhimg} source={require('../assets/images/search.png')} />
      </Pressable>
    </View>

  </View>
  )
}
  


  export  const styles = StyleSheet.create({
    hdrnavwrap: {
      marginTop:90,
      flexDirection:'row',
      justifyContent:'space-between',
      paddingLeft:10,
      paddingRight:10,
      paddingBottom:10,
      
    },
    btmbtn:{
      paddingLeft:10,
      paddingRight:10,
    },
    btnText:{
      color:'#fff',
      fontSize:14,
      fontFamily:'PoppinsRegular',
    },
    alglft:{
      flexDirection:'row',

    },
    userimg:{
      width:36,
      height:36,
      borderRadius:30,
    },
    notimg:{
      width:27,
      height:24,
      marginTop:6,
    },
    srhimg:{
      width:24,
      height:24,
      marginTop:4,

    }


    
  
  });
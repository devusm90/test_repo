import { SafeAreaView,ScrollView, StyleSheet, Text, Image, View, TextInput, Pressable, Alert,ImageBackground,Dimensions } from 'react-native';

import { useNavigation } from '@react-navigation/native';




export default function BottomNav() {

  const navigation = useNavigation();

  const goHome =()=>{
    navigation.navigate('Home')
  }


  return (
 
    <View style={styles.btmnavwrap}>
      <Pressable style={styles.btmbtn} onPress={goHome}>
        <Image style={styles.icon} source={require('../assets/images/home.png')} />
        <Text style={styles.btnText}>Home</Text>
      </Pressable>
      <Pressable style={styles.btmbtn} onPress={() => navigation.navigate('Learn')}>
      <Image style={styles.icon} source={require('../assets/images/learn.png')} />
        <Text style={styles.btnText}>Learn</Text>
      </Pressable>
      <Pressable style={styles.btmbtn} onPress={() => navigation.navigate('Revise')}>
      <Image style={styles.icon} source={require('../assets/images/revice.png')} />
        <Text style={styles.btnText}>Revise</Text>
      </Pressable>
      <Pressable style={styles.btmbtn} onPress={() => navigation.navigate('Quiz')}>
        <Image style={styles.icon} source={require('../assets/images/quizicon.png')} />
        <Text style={styles.btnText}>Quiz</Text>
      </Pressable>
    </View>

  );
}

const styles = StyleSheet.create({

  btmnavwrap: {
    flexDirection:'row',
    justifyContent:'space-between',
    paddingTop:6,
    paddingLeft:10,
    paddingRight:10,
    
  },
  btmbtn:{
    padding:6,
  },
  btnText:{
    color:'#fff',
    fontSize:14,
    fontFamily:'PoppinsRegular',
  },
  icon:{
    width:26,
    height:26,
    marginLeft:'auto',
    marginRight:'auto',
  }



});

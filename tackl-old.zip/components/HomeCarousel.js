import React from 'react'
import Carousel, { Pagination } from 'react-native-snap-carousel'



import { View, Text, StyleSheet, Dimensions, Image, ImageBackground } from "react-native";

export const SLIDER_WIDTH = Dimensions.get('window').width;
export const ITEM_WIDTH = Math.round(SLIDER_WIDTH * 0.899)

const data = [
    {
      title: "Live Now",
      body: "Mock Test",
      imgUrl: "https://picsum.photos/id/11/200/300",
    },
    {
      title: "In turpis",
      body: "Aenean ut eros",
      imgUrl: "https://picsum.photos/id/10/200/300",
    },
    {
      title: "Lorem Ipsum",
      body: "Phasellus ullam",
      imgUrl: "https://picsum.photos/id/12/200/300",
    },
  ];




const CarouselCardItem = ({ item, index }) => {
    return (
      <View style={styles.container} key={index}>
        <Image source={{ uri: item.imgUrl }} style={styles.image} />
        <Text style={styles.header}>{item.title}</Text>
        <Text style={styles.body}>{item.body}</Text>
        <Image  style={styles.blueline} source={require('../assets/images/banner-line.png')} />
      </View>
    )
  }



const HomeCarousel = () => {
  const [index, setIndex] = React.useState(0)
  const isCarousel = React.useRef(null)


  return (
    <View>
      <Carousel
        layout="default"
        layoutCardOffset={9}
        ref={isCarousel}
        data={data}
        renderItem={CarouselCardItem}
        sliderWidth={SLIDER_WIDTH}
        itemWidth={ITEM_WIDTH}
        onSnapToItem={(index) => setIndex(index)}
        useScrollView={true}
      />
      <Pagination
        dotsLength={data.length}
        activeDotIndex={index}
        carouselRef={isCarousel}
        dotStyle={{
          width: 10,
          height: 10,
          borderRadius: 5,
          marginHorizontal: 0,
          backgroundColor: '#777BD1'
        }}
        inactiveDotOpacity={0.6}
        inactiveDotScale={1}
        tappableDots={true}
      />
    </View>

  )
}


const styles = StyleSheet.create({
    container: {
      backgroundColor: '#18191C',
      elevation: 7,
      borderRadius:10,
      padding:20,
      position:'relative',
      paddingLeft:160,
    },
    image:{
      width:140,
      height:115,
      position:'absolute',
      left:0,
      top:0,

    },
    header:{
      fontFamily:'PoppinsBold',
      color: '#ED813F',
      fontSize:14,
    },
    body:{
      fontSize: 20,
      color:'#FFF1E4',
      fontFamily:'RecoletaRegular',
    },
    blueline:{
      width:100,
      height:16,
      marginTop:10,

    },
  })

export default HomeCarousel

import { SafeAreaView,ScrollView, StyleSheet, Text, Image, View, TextInput, Pressable, Alert,ImageBackground } from 'react-native';
import { StatusBar } from 'expo-status-bar';


import Container from '../components/Container';
import HeaderNav from '../components/HeaderNav';
import BottomNav from '../components/BottomNav';

import HomeCarousel from '../components/HomeCarousel';




export default function Home({navigation}: {navigation: any}) {



  return (
    <Container>
      <HeaderNav/>
    
      <ScrollView contentContainerStyle={styles.scrollview} >
        <View>
          <Text style={styles.title}>Hi Maalty</Text>
          <Text style={styles.subtitle}>Let us help you to learn more efficiently</Text>
          <Image  style={styles.yeloline} source={require('../assets/images/yellow-line.png')} />
        </View>
        <SafeAreaView style={styles.popup}>
          <Text style={styles.popuptext}>Get to know  <Image style={styles.logo} source={require('../assets/images/tackl.png')} /></Text>

          <Image style={styles.clsbtn} source={require('../assets/images/close.png')} />
        </SafeAreaView>

        <View style={styles.banner}>
          <HomeCarousel />
        </View>

        <View style={styles.prfwrap}>
        <ImageBackground source={require('../assets/images/perf-bg.png')} style={styles.prfbg}>
          <Text style={styles.prftitle}>Performance</Text>
          <Text style={styles.prfsub}>Start learn to see your performance</Text>
          <Image style={styles.rightarow} source={require('../assets/images/right-arrow.png')} />
          </ImageBackground>
        </View>

        <View style={styles.corwrap}>
          <Image style={styles.eracebg} source={require('../assets/images/eraser.png')} />
          <Text style={styles.cortitle}>Correction Bucket</Text>
          <Text style={styles.corsub}>Re-attempt wrong answers</Text>
          <Text style={styles.corwrng}>12 wrong answers<Image style={styles.rightblue} source={require('../assets/images/right-blue.png')} /></Text>
          <Image style={styles.redline} source={require('../assets/images/red-line.png')} />
        </View>


        <Text style={styles.bkmtitle}>Bookmark</Text>
        <Image  style={styles.yeloline} source={require('../assets/images/yellow-line.png')} />

        <View style={styles.bkmwrap}>
          <Image  style={styles.bkmimg} source={require('../assets/images/bookmark-img.png')} />
          <Text style={styles.bkmtext}>Add BookMarks to revise more efficiently</Text>
        </View>
        



      </ScrollView>
      <BottomNav navigation={undefined}   />
      
      </Container>
  );
}

const styles = StyleSheet.create({
  container: {
    flex:1,
    backgroundColor:'#0b0b13',
  },
  bgimage:{
    flex:1,
    position:'absolute',
    width:'100%',
    height:'100%',
  },

  title:{
    fontFamily:'RecoletaBold',
    color: '#FFF1E4',
    fontSize:27,
    textAlign:'center',
    marginTop:10,
    marginBottom:10,
  },
  subtitle:{
    fontSize: 14,
    color:'#FFF1E4',
    textAlign:'center',
    fontFamily:'PoppinsRegular',
  },
  yeloline:{
    width:60,
    height:4,
    marginLeft:'auto',
    marginRight:'auto',
    marginTop:6,
  },
  popup:{
    padding:10,
    paddingLeft:20,
    backgroundColor:'#18191C',
    margin:20,
    marginBottom:0,
    borderRadius:16,
    position:'relative',
  },
  popuptext:{
    color:'#FFF1E4',
    fontFamily:'PoppinsRegular',
    fontSize:18,
  },
  logo:{
    width:84,
    height:22,
  },
  clsbtn:{
    width:16,
    height:16,
    position:'absolute',
    top:18,
    right:20,
  },
  banner:{
    paddingTop:20,
  },
  prfwrap:{
    backgroundColor:'#18191C',
    borderRadius:16,
    margin:20,
    marginTop:0,
    position:'relative',
  },
  prfbg:{
    padding:20,
    paddingLeft:30,
  },
  prftitle:{
    fontFamily:'RecoletaBold',
    color: '#FFF1E4',
    fontSize:22,
    marginBottom:10,
  },
  prfsub:{
    color:'#FFF1E4',
    fontFamily:'PoppinsRegular',
    fontSize:22,
  },
  corwrap:{
    padding:20,
    backgroundColor:'#18191C',
    borderRadius:16,
    margin:20,
    marginTop:0,
    position:'relative',
    overflow:'hidden',
  },
  eracebg:{
    width:110,
    height:146,
    position:'absolute',
    top:0,
    right:0,

  },
  cortitle:{
    fontFamily:'RecoletaBold',
    color: '#FFF1E4',
    fontSize:20,
    marginBottom:10,
  },
  corsub:{
    color:'#FFF1E4',
    fontFamily:'PoppinsSemiBold',
    fontSize:14,
    opacity:.7,
  },
  rightarow:{
    width:20,
    height:18,
    position:'relative',
    left:4,
    marginTop:10,

  },
  corwrng:{
    fontFamily:'PoppinsBold',
    color:'#FFF1E4',
    marginTop:4,
  },
  rightblue:{
    width:20,
    height:20,
    paddingLeft:10,

  },
  redline:{
    width:140,
    height:10,
  },
  bkmtitle:{
    fontFamily:'RecoletaBold',
    color: '#FFF1E4',
    fontSize:20,
    textAlign:'center',
    marginTop:20,
  },
  bkmwrap:{
    padding:20,
    backgroundColor:'#18191C',
    borderRadius:16,
    margin:20,
    paddingLeft:90,
    position:'relative',
  },
  bkmtext:{
    color:'#FFF1E4',
    fontFamily:'PoppinsRegular',
    fontSize:16,
    opacity:.7,
  },
  bkmimg:{
    width:40,
    height:50,
    position:'absolute',
    top:20,
    left:30,

  },
  scrollview:{

  }
  

});

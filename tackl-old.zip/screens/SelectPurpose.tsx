import { SafeAreaView,ScrollView, StyleSheet, Text, Image, View, TextInput, Pressable, Alert,ImageBackground } from 'react-native';
import { StatusBar } from 'expo-status-bar';




export default function SelectPurpose({navigation}: {navigation: any}) {
  return (
      <View style={styles.container}>
      <ImageBackground source={require('../assets/images/main-bg-full.png')} style={styles.bgimage}></ImageBackground>

      <ScrollView contentContainerStyle={styles.scrollview} >

        <Text style={styles.title}>I’m here for</Text>
        <Image style={styles.yeloline} source={require('../assets/images/yellow-line.png')} />


        <SafeAreaView style={styles.content}>
          <Pressable onPress={() => navigation.navigate('YourName')}>
            <Image  style={styles.bookimg} source={require('../assets/images/book.png')} />
            <Text style={styles.subtitle}>Exam preparation</Text>
            <Text style={styles.whitetext}>Let us help you to learn more efficiently</Text>
          </Pressable>
        </SafeAreaView>
        <SafeAreaView style={styles.content}>
          <Pressable onPress={() => navigation.navigate('Quiz')}>
            <Image  style={styles.quizimg} source={require('../assets/images/quiz.png')} />
            <Text style={styles.subtitle}>Quiz</Text>
            <Text style={styles.whitetext}>Let us help you to learn more efficiently</Text>
          </Pressable>
        </SafeAreaView>






        




        </ScrollView>

      </View>





  );
}

const styles = StyleSheet.create({
  container: {
    flex:1,
    backgroundColor:'#0b0b13',
  },
  bgimage:{
    flex:1,
    position:'absolute',
    width:'100%',
    height:'100%',
  },
  title:{
    fontFamily:'RecoletaBold',
    color: '#FFF1E4',
    fontSize:27,
    textAlign:'center',
    marginTop:120,
    marginBottom:10,
  },
  yeloline:{
    width:60,
    height:4,
    marginLeft:'auto',
    marginRight:'auto',
    marginTop:6,
    marginBottom:20,

  },
  content:{
    alignSelf: 'stretch',
    padding:20,
    backgroundColor:'#18191C',
    margin:20,
    marginBottom:0,
    borderRadius:16,
  },
  bookimg:{
    width:150,
    height:150,
    marginLeft:'auto',
    marginRight:'auto',
  },
  quizimg:{
    width:120,
    height:120,
    marginLeft:'auto',
    marginRight:'auto',
    marginBottom:10,
  },
  subtitle:{
    fontFamily:'RecoletaBold',
    color: '#FFF1E4',
    fontSize:20,
    textAlign:'center',
    marginBottom:10,
  },
  whitetext:{
    fontSize: 14,
    color:'#FFF1E4',
    textAlign:'center',
    fontFamily:'PoppinsRegular',
  }


});


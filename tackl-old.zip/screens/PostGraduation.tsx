import React, { useState } from 'react';
import { Dimensions , SafeAreaView,ScrollView, StyleSheet, Text, Image, View, TextInput, Pressable, Alert,ImageBackground } from 'react-native';
import { StatusBar } from 'expo-status-bar';

import Container, { styles as cardStyles } from '../components/Container';
import RadioGroup, {RadioButtonProps} from 'react-native-radio-buttons-group';
import DropDownPicker from "react-native-dropdown-picker";
import { FontAwesomeIcon } from "@fortawesome/react-native-fontawesome";
import RadioButtonGroup, { RadioButtonItem } from "expo-radio-button";

var width = Dimensions.get('window').width; //full width
var height = Dimensions.get('window').height; //full height



var width = Dimensions.get('window').width; //full width
var height = Dimensions.get('window').height; //full height




export default function Branch({navigation}: {navigation: any}) {

  const [current, setCurrent] = useState("test");

  const state = {
    checked: 'first',
  };

  const Homescrn =()=>{
    navigation.navigate('Personalised');
  }

  const [open, setOpen] = useState(false);
  const [value, setValue] = useState(null);
  const [items, setItems] = useState([
    {label: 'Kerala', value: 'kl'},
    {label: 'Andhra Pradesh', value: 'ap'},
    {label: 'Bihar', value: 'bi'},
  ]);

  const [collegeopen, setCollegeOpen] = useState(false);
  const [collegevalue, setCollegeValue] = useState(null);
  const [collegeitems, setCollegeItems] = useState([
    {label: 'M E S Medical College', value: 'mes'},
    {label: 'College2', value: 'college'}
  ]);

  const [yearopen, setYearOpen] = useState(false);
  const [yearvalue, setYearValue] = useState(null);
  const [yearitems, setYearItems] = useState([
    {label: '2020', value: '2020'},
    {label: '2021', value: '2021'}
  ]);

  
  

const name = "Maalty";
  return (
    <Container>     

      <View style={styles.topading}>        
        <SafeAreaView style={styles.content}>
          <RadioButtonGroup
            containerStyle={{ marginBottom: 0 }}
            selected={current}
            onSelected={(value: React.SetStateAction<string>) => setCurrent(value)}
            containerOptionStyle={{margin:8,}}
            radioBackground="#fff"
            radioStyle={{backgroundColor:"#777BD1",borderWidth:5,borderColor:"#777BD1",opacity:1}}
            size={26}
          >
            <RadioButtonItem 
                value="test2"
                label={
                  <Text style={styles.label}>Medical</Text>
                }
            />
            <RadioButtonItem
              value="test"
              label={
                <Text style={styles.label}>Engineering</Text>
              }
            />
            </RadioButtonGroup>       
        </SafeAreaView>
        <Text style={styles.subheading}>State, Collage, Year</Text>

        <View style={styles.seltwrap}>
          <DropDownPicker
            open={open}
            value={value}
            items={items}
            setOpen={setOpen}
            setValue={setValue}
            setItems={setItems}
            zIndex={20}
            placeholder="State"
            closeAfterSelecting={true}
            style={{
              backgroundColor: "#18191C",
              height:60,
              paddingLeft:20,
              borderRadius:12,
            }}
            arrowIconStyle={{
              width: 30,
              height: 30,
            }}
            dropDownContainerStyle={{
              backgroundColor: "#18191C",
              padding:10,
            }} 
            textStyle={{
              fontSize: 16,
              color:'#6E7191',
              fontFamily:'RobotoMedium',
            }}
          />
          <View style={styles.space}></View>
          <DropDownPicker
            open={collegeopen}
            value={collegevalue}
            items={collegeitems}
            setOpen={setCollegeOpen}
            setValue={setCollegeValue}
            setItems={setCollegeItems}
            zIndex={18}
            placeholder="Collage"
            closeAfterSelecting={true}
            style={{
              backgroundColor: "#18191C",
              height:60,
              paddingLeft:20,
              borderRadius:12,
            }}
            arrowIconStyle={{
              width: 30,
              height: 30,
            }}
            
            dropDownContainerStyle={{
              backgroundColor: "#18191C",
              padding:10,
            }} 
            textStyle={{
              fontSize: 16,
              color:'#6E7191',
              fontFamily:'RobotoMedium',
            }}
          />
          <View style={styles.space}></View>
          <DropDownPicker
            open={yearopen}
            value={yearvalue}
            items={yearitems}
            setOpen={setYearOpen}
            setValue={setYearValue}
            setItems={setCollegeItems}
            zIndex={16}
            placeholder="Year"
            closeAfterSelecting={true}
            style={{
              backgroundColor: "#18191C",
              height:60,
              paddingLeft:20,
              borderRadius:12,
            }}
            arrowIconStyle={{
              width: 30,
              height: 30,
            }}
            
            dropDownContainerStyle={{
              backgroundColor: "#18191C",
              padding:10,
            }} 
            textStyle={{
              fontSize: 16,
              color:'#6E7191',
              fontFamily:'RobotoMedium',
            }}
          />
        </View>

       
      


        <Pressable style={styles.btn} onPress={Homescrn}>
          <Text style={styles.btnText}>Save</Text>
        </Pressable>
        

        
      </View>
    </Container>




  );
}



const styles = StyleSheet.create({

  topading:{
    paddingTop:120,
    position:"relative",
    height:height
  },
  title:{
    fontFamily:'RecoletaBold',
    color: '#FFF1E4',
    fontSize:27,
    textAlign:'center',
  },
  subheading:{
    fontFamily:'PoppinsRegular',
    color: '#FFF1E4',
    fontSize:14,
    textAlign:'center',
    marginBottom:25,
    marginTop:60
  },
  chalkimg:{
    width:9,
    height:28,
    position:'relative',
    left:20,
  },
  yeloline:{
    width:60,
    height:4,
    marginLeft:'auto',
    marginRight:'auto',
    marginTop:10,
  },
  whitetxt:{
    color:'#fff',
    textAlign:'center',
    fontSize:24,
    fontFamily:'PoppinsRegular',
  },
  bold:{
    fontWeight:'bold',
  },
  cant:{
    paddingTop:60,
  },
  takicon:{
    width:20,
    height:20,
    position:'relative',
    left:-10
  },
  curvewrap:{
    textAlign:'right',
    marginTop:40,
    marginBottom:40,
    display:'flex',
    alignItems:'center'
  },
  curve:{
    width:80,
    height:61,
    alignSelf: 'flex-end',
    marginRight:40,
  },
  content:{
    alignSelf: 'stretch',
    padding:20,
    backgroundColor:'#18191C',
    margin:20,
    marginBottom:0,
    borderRadius:16,
  },
  selectbox:{
    marginBottom:24,
    paddingLeft:20,
    paddingRight:20,
    marginRight:20,
    width:'100%',
    
  },
  frmlabel:{
    color:'#FFF1E4',
    fontFamily:'PoppinsRegular',
    fontSize:14,
    padding:20,
  },
  label:{
    color:'#6E7191',
    fontSize:15,
    fontFamily:'PoppinsSemiBold',
    paddingLeft:10,
  },
  btn:{
    backgroundColor:'#787bd1',
    marginTop:30,
    height:50,
    borderRadius:12,
    width:280,
    textAlign:'center',
    marginLeft:'auto',
    marginRight:'auto',
    position:'absolute',
    left:width / 2 -140,
    bottom:0
  },
  btnText:{
    color:'#fff',
    textAlign:'center',
    fontSize:16,
    fontWeight:'bold',
    paddingTop:15
  },
  seltwrap:{
    paddingLeft:20,
    paddingRight:20,
  },
  space:{
    height:20,
  }

});

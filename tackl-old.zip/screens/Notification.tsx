import { SafeAreaView,ScrollView, StyleSheet, Text, Image, View, TextInput, Pressable, Alert,ImageBackground } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import Container from '../components/Container';
import BottomNav from '../components/BottomNav';




export default function Notification({navigation}: {navigation: any}) {
  return (
    <Container>
      <ScrollView>
        <Text style={styles.title}>Notification</Text>
      </ScrollView>
      <BottomNav/>
    </Container>
  );
}

const styles = StyleSheet.create({

  title:{
    fontFamily:'RecoletaBold',
    color: '#FFF1E4',
    fontSize:27,
    textAlign:'center',
    marginTop:120,
    marginBottom:10,
  },


});

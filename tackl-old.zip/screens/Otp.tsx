import { SafeAreaView,ScrollView, StyleSheet, Text, Image, View, TextInput, Pressable, Alert,ImageBackground,Dimensions } from 'react-native';

import Container, { styles as cardStyles } from '../components/Container';




export default function Otp({navigation}: {navigation: any}) {

  const createAccount =()=>{
    navigation.navigate('YourName')
  }


  return (
    <Container>
      <View style={styles.container}>
      <View style={styles.top}>
        <Text style={styles.title}>Enter OTP</Text>
        <Text style={styles.subtitle}>Enter the OTP sent to you just now</Text>
        <View>
          <Image  style={styles.yeloline} source={require('../assets/images/yellow-line.png')} />
          <Image  style={styles.otpimg} source={require('../assets/images/otp-img.png')} />
          <Image  style={styles.arrow} source={require('../assets/images/arrow.png')} />
        </View>
        

      </View>
      <View style={styles.bottom}>
      <SafeAreaView style={styles.content}>
        <View style={styles.otpWrap}>
          <TextInput style={styles.input} placeholderTextColor="#6E7191"/>
          <TextInput style={styles.input} placeholderTextColor="#6E7191"/>
          <TextInput style={styles.input} placeholderTextColor="#6E7191"/>
          <TextInput style={styles.input} placeholderTextColor="#6E7191"/>
        </View>
        <Pressable style={styles.btn} onPress={createAccount}>
          <Text style={styles.btnText}>Proceed</Text>
        </Pressable>


        <Text style={styles.resnd}>
          <Text>Resend in</Text>
          <Text style={styles.resndbold}> 50 Sec</Text>
        </Text>

        <Text style={styles.cngeno} onPress={() => navigation.navigate('SignUp')}>
        Change Number
        </Text>
      </SafeAreaView>

      </View>
      </View>
    </Container>

  );
}

const styles = StyleSheet.create({
  container: {
    flex:1,
    flexDirection:'column',
  },
  top:{
    flex:1.8,

  },
  bottom:{
    flex:1,
    backgroundColor:'#18191C'
  },
  bgimage:{
    flex:1,
    position:'absolute',
    width:'100%',
    height:'100%',
  },
  title:{
    
    fontFamily:'RecoletaBold',
    color: '#FFF1E4',
    fontSize:24,
    textAlign:'center',
    marginTop:120,
    marginBottom:10,
  },
  subtitle:{
    fontSize: 14,
    color:'#FFF1E4',
    textAlign:'center',
    fontFamily:'PoppinsRegular',
  },
  yeloline:{
    width:60,
    height:4,
    marginLeft:'auto',
    marginRight:'auto',
    marginTop:6,

  },
  otpimg:{
    marginTop:30,
    marginLeft:'auto',
    marginRight:'auto',
  },
  arrow:{
    marginLeft:'auto',
    marginRight:'auto',
  },
  content:{
    alignSelf: 'stretch',
    paddingTop:26,
    backgroundColor:'#18191C',
    paddingBottom:20,

  },
  otpWrap:{
    display:'flex',
    justifyContent:'center',
    flexDirection: "row",
  },
  input:{
    borderColor:'#6E7191',
    borderWidth:1,
    backgroundColor:'#0B0B13',
    color:'#fff',
    height:50,
    fontSize:16,
    width:60,
    marginLeft:6,
    marginRight:6,
    borderRadius:10,
    textAlign:'center',
  },
  btn:{
    backgroundColor:'#787bd1',
    marginTop:30,
    height:50,
    borderRadius:12,
    width:280,
    textAlign:'center',
    marginLeft:'auto',
    marginRight:'auto',
},
btnText:{
  color:'#fff',
  textAlign:'center',
  fontSize:16,
  fontWeight:'bold',
  paddingTop:15
},
resnd:{
  fontSize: 16,
  color:'#FFF1E4',
  textAlign:'center',
  fontFamily:'PoppinsRegular',
  marginTop:20,
},
resndbold:{
  fontWeight:'bold',
  color:'#FCFCFC',
},
cngeno:{
  color:'#777BD1',
  textAlign:'center',
  marginTop:20,
  fontSize:16,
},


});

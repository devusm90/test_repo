import React from 'react'
import { SafeAreaView,ScrollView, StyleSheet, Text, Image, View, TextInput, Pressable, Alert,ImageBackground } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import CarouselCards from '../components/WelcomeCarousel';
import Container from '../components/Container';








export default function Welcome({navigation}: {navigation: any}) {

  
  const signup =()=>{
    navigation.navigate('SignUp')
  }

  
    
  const isCarousel = React.useRef(null)

  return (
    <Container>
          <StatusBar style="light" backgroundColor="#0b0b13"/>
          <Pressable style={styles.btn} onPress={signup}>
            <Text style={styles.btnText}>Skip</Text>
          </Pressable>    
          <View style={styles.logowrap}>
            <Image style={styles.logo} source={require('../assets/images/tackl.png')} />
          </View>    

          <SafeAreaView>
            <CarouselCards />
          </SafeAreaView>     
    </Container>

  );
}

const styles = StyleSheet.create({

  title:{
    fontFamily:'RecoletaBold',
    color: '#FFF1E4',
    fontSize:27,
    textAlign:'center',
    marginTop:120,
    marginBottom:10,
  },
  btn:{
    padding:20,
    paddingTop:50,

  },
  btnText:{
    color:'#FFF1E4',
    textAlign:'right',
    fontSize:18,
  },
  logo:{
    width:150,
    height:41,
    marginLeft:'auto',
    marginRight:'auto',
    marginTop:20,
  },
  logowrap:{
    paddingTop:10,
    paddingBottom:40
  },

});

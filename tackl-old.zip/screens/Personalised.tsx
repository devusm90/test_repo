import { SafeAreaView,ScrollView, StyleSheet, Text, Image, View, TextInput, Pressable, Alert,ImageBackground } from 'react-native';
import { StatusBar } from 'expo-status-bar';

import Container from '../components/Container';



export default function Personalised({navigation}: {navigation: any}) {

  const goHome =()=>{
    navigation.navigate('Home')
  }



  return (
    <Container>

      <View style={styles.middlealign}>
        <View>
          <Image style={styles.logo} source={require('../assets/images/tackl-icon.png')} />
        </View>

        <View style={styles.textwrap}>
          <Text style={styles.text}>Customizing Your</Text>
          <Text style={styles.text}>Personalised Experience</Text>
        </View>
        

        <Pressable onPress={goHome}>
          <Text style={styles.btnText}>Skip</Text>
        </Pressable>

      </View>


       



    </Container>

  );
}

const styles = StyleSheet.create({
  middlealign:{
    flex:1,
    justifyContent:'center',
  },
  textwrap:{
    paddingTop:20,
    paddingBottom:20,

  },
  text:{
    color: '#FFF1E4',
    textAlign:'center',
    fontSize:18,
    fontFamily:'PoppinsRegular',
  },
  logo:{
    width:100,
    height:100,
    marginLeft:'auto',
    marginRight:'auto',
    marginTop:20,
  },
  btnText:{
    color:'#fff',
    textAlign:'center',
    fontSize:16,
    fontWeight:'bold',
    paddingTop:15
  },

});

import { SafeAreaView,ScrollView, StyleSheet, Text, Image, View, TextInput, Pressable, Alert,ImageBackground } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import Container from '../components/Container';




export default function Dummy({navigation}: {navigation: any}) {
  return (
    <Container>
      <Text style={styles.title}>Dummy</Text>
    </Container>
  );
}

const styles = StyleSheet.create({

  title:{
    fontFamily:'RecoletaBold',
    color: '#FFF1E4',
    fontSize:27,
    textAlign:'center',
    marginTop:120,
    marginBottom:10,
  },


});

import React, { useState } from 'react';
import { SafeAreaView,ScrollView, StyleSheet, Text, Image, View, TextInput, Pressable, Alert,ImageBackground } from 'react-native';
import { StatusBar } from 'expo-status-bar';

import Container, { styles as cardStyles } from '../components/Container';
import RadioButtonGroup, { RadioButtonItem } from "expo-radio-button";


export default function Branch(this: any, {navigation}: {navigation: any}) {

  const [current, setCurrent] = useState("test");

  const state = {
    checked: 'first',
  };

  const Homescrn =()=>{
    navigation.navigate('Exam');
  }

 
  // const [checked, setChecked] = React.useState('first');


const name = "Maalty";
  return (
    <Container>
      
      { <Pressable style={styles.btn} onPress={Homescrn}>
        <Text style={styles.btnText}>Skip</Text>
      </Pressable>}



      <View style={styles.topading}>
        <Text style={styles.title}>
          Hi {name} <Image style={styles.chalkimg} source={require('../assets/images/chalk-mark.png')} />
        </Text>
        <Image style={styles.yeloline} source={require('../assets/images/yellow-line.png')} />

        <SafeAreaView style={styles.cant}>
          <Text style={styles.whitetxt}>Can't wait to get</Text>
          <Text style={styles.whitetxt}><Image style={styles.takicon} source={require('../assets/images/tackl-icon.png')} /><Text style={styles.bold}>tackling</Text> together!</Text>
          <View style={styles.curvewrap}><Image style={styles.curve} source={require('../assets/images/curve.png')} /></View>
        </SafeAreaView>

        <SafeAreaView style={styles.content}>
          <Text style={styles.frmlabel}>Please select the Branch</Text> 
            <RadioButtonGroup
                containerStyle={{ marginBottom: 0 }}
                selected={current}
                onSelected={(value: React.SetStateAction<string>) => setCurrent(value)}
                containerOptionStyle={{margin:8,}}
                radioBackground="#fff"
                radioStyle={{backgroundColor:"#777BD1",borderWidth:5,borderColor:"#777BD1",opacity:1}}
                size={26}
              >
                <RadioButtonItem 
                    value="medical" 
                    label={
                      <Text style={styles.label}>Medical</Text>
                    }
                />
                <RadioButtonItem
                  value="engineering"
                  label={
                    <Text style={styles.label}>Engineering</Text>
                  }
                />
              </RadioButtonGroup>
        </SafeAreaView>
      </View>
    </Container>

  );
}



const styles = StyleSheet.create({

  topading:{
    paddingTop:0,
    flex:1,
    flexDirection:'column',
    justifyContent:'center',
  },
  title:{
    fontFamily:'RecoletaBold',
    color: '#FFF1E4',
    fontSize:27,
    textAlign:'center',
  },
  chalkimg:{
    width:9,
    height:28,
    position:'relative',
    left:20,
  },
  yeloline:{
    width:60,
    height:4,
    marginLeft:'auto',
    marginRight:'auto',
    marginTop:10,
  },
  whitetxt:{
    color:'#fff',
    textAlign:'center',
    fontSize:24,
    fontFamily:'PoppinsRegular',
  },
  bold:{
    fontWeight:'bold',
  },
  cant:{
    paddingTop:60,
  },
  takicon:{
    width:20,
    height:20,
    position:'relative',
    left:-10
  },
  curvewrap:{
    textAlign:'right',
    marginTop:40,
    marginBottom:40,
    display:'flex',
    alignItems:'center'
  },
  curve:{
    width:80,
    height:61,
    alignSelf: 'flex-end',
    marginRight:40,
  },
  content:{
    padding:20,
    backgroundColor:'#18191C',
    margin:20,
    marginBottom:0,
    borderRadius:16,
  },
  frmlabel:{
    color:'#FFF1E4',
    fontFamily:'PoppinsRegular',
    fontSize:14,
    padding:20,
  },
  label:{
    color:'#6E7191',
    fontSize:15,
    fontFamily:'PoppinsSemiBold',
    paddingLeft:10,
  },
  btn:{
    padding:20,
    paddingTop:85,
  },
  btnText:{
    color:'#FFF1E4',
    textAlign:'right',
    fontSize:16,
  },
  alignment:{
   
    
  },

});
